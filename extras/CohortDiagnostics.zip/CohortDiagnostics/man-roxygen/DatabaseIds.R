#' @param databaseIds           A vector one or more databaseIds to retrieve the results for. This is a 
#'                              character field values from the `databaseId` field of the `database` table 
#'                              of the results data model.
