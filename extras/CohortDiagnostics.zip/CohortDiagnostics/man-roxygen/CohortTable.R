#' @param cohortDatabaseSchema   Schema name where your cohort table resides. Note that for SQL Server,
#'                               this should include both the database and schema name, for example
#'                               'scratch.dbo'.
#' @param cohortTable            Name of the cohort table.
