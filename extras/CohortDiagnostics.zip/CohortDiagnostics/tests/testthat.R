library(testthat)
test_check("CohortDiagnostics")
