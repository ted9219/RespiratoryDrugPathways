SELECT distinct relationship.*
  FROM @vocabulary_database_schema.relationship;
